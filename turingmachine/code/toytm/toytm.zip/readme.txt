TM - Toy Code Interpreter

TM-Interpreter for Toy Code

No Line Numbers in the Toy Code are supported!
Use -in2 for loading the Toy-Code (allows multiline toy code)